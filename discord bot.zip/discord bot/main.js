const Discord = require('discord.js');

const client = new Discord.client();


client.once('ready', () => {
    console.log('TurtleBot is online!');
});

client.login('OTIwNTI5ODQ4NTkyNjUwMjkw.YblsOg.ZX_dasyk-7ZK6aBXO2jLw-YAU7k');
